const startPage = require('./startPage');
const publicFiles = require('./publicFiles');

module.exports = {
  startPage,
  publicFiles
};